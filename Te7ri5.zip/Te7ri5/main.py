CFG = {
    "drop_speed" : 2, # Times per second
    
    "grid_x" : 10,
    "grid_y" : 24, 

    "tcp_port" : 65432,

    "debug_show_matrix" : False,
    "debug_show_obj_matrix" : False,

    "objs" : [ 
    [
        [0,0,0,0],
        [0,1,1,0],
        [0,1,1,0],
        [0,0,0,0]
    ],
    [
        [0,0,0,0],
        [1,1,0,0],
        [0,1,1,0],
        [0,0,0,0]
    ],
    [
        [0,1,0,0],
        [0,1,0,0],
        [0,1,0,0],
        [0,1,0,0]
    ],
    [
        [0,1,0,0],
        [0,1,0,0],
        [0,1,1,0],
        [0,0,0,0]
    ],
    [
        [0,1,0,0],
        [0,1,1,0],
        [0,1,0,0],
        [0,0,0,0]
    ]
    ]
}

from Modules import line_clear as LineClear
import curses, socket, json, random
from time import time as tick

Grids = {
}

obj_pos = {"x": 2, "y": 0}
Obj_Grid = []

# Physics variables
last_drop_tick = 0

opponent_ip = "127.0.0.1"

Menu_Vars = [
    {
        "select" : 0,
    },
    {

    },
    {
        "conn_bar" : "---       ",
    },
]

menu_stage = 0
run_context = 0 # 0 = host, 1 = client

# FUKN DICKHED!!!
def CombineMatrices():

    Dummy_Matrix = []

    for y in range(0, CFG["grid_y"]):
        Dummy_Matrix.append([])
        for x in range(0, CFG["grid_x"]):
            Dummy_Matrix[y].append(1)

    for y_coord, Y_Row in enumerate(Grids["Player1"]):
        for x_coord, color in enumerate(Y_Row):
            abs_y_coord = y_coord
            abs_x_coord = x_coord
            Dummy_Matrix[abs_y_coord][abs_x_coord] = color

    for y_coord, Y_Row in enumerate(Obj_Grid):
        for x_coord, color in enumerate(Y_Row):
            if color == 0 or color == 1: continue;
            abs_y_coord = obj_pos["y"] + y_coord
            abs_x_coord = obj_pos["x"] + x_coord
            if not abs_x_coord in range(0, CFG["grid_x"]): continue;
            if not abs_y_coord in range(0, CFG["grid_y"]): continue;
            Dummy_Matrix[abs_y_coord][abs_x_coord] = color

    return Dummy_Matrix

def Strafe(dir):
    global obj_pos
    for y_coord, Y_Row in enumerate(Obj_Grid):
        for x_coord, color in enumerate(Y_Row):
            if color == 1: continue;
            abs_x_coord = obj_pos["x"] + x_coord
            if dir == -1 and abs_x_coord <= 0: return;
            if dir == 1 and abs_x_coord >= CFG["grid_x"] - 1: return;
    obj_pos = {"x": obj_pos["x"] + dir, "y": obj_pos["y"]} 
    overlapped = IsOverlapped()
    if overlapped == 1: pass;
    elif overlapped:
        obj_pos = {"x": obj_pos["x"] - dir, "y": obj_pos["y"]} 

def IsOverlapped():
    for y_coord, Y_Row in enumerate(Obj_Grid):
        for x_coord, color in enumerate(Y_Row):
            if color == 0 or color == 1: continue;
            abs_y_coord = obj_pos["y"] + y_coord
            abs_x_coord = obj_pos["x"] + x_coord
            if not abs_x_coord in range(0, CFG["grid_x"]): continue;
            if not abs_y_coord in range(0, CFG["grid_y"]): continue;
            if Grids["Player1"][abs_y_coord][abs_x_coord] > 1: return True;
            if abs_y_coord > CFG["grid_y"] - 5: return True;
        
            if abs_x_coord <= - 1: return True;
            if abs_x_coord >= CFG["grid_x"]: return 1;
    return False

def SpawnPart():
    global obj_pos, Obj_Grid

    obj_pos = {"x": 2, "y": 0}
    selection = random.randint(0, 4)
    rand_color = random.randint(2, 7)
    Obj_Grid = []
    for y_coord, Y_Row in enumerate(CFG["objs"][selection]):
        Obj_Grid.append([])
        for x_coord, color in enumerate(Y_Row):
            Obj_Grid[y_coord].append(color)

    for y_coord, Y_Row in enumerate(Obj_Grid):
        for x_coord, color in enumerate(Y_Row):
            Obj_Grid[y_coord][x_coord] = color * (rand_color) + 1
SpawnPart()

def AutoDrop():
    global last_drop_tick, obj_pos
    if tick() - last_drop_tick < 1 / CFG["drop_speed"]: return; 
    last_drop_tick = tick()

    PushDown()

def PushDown():
    obj_pos["y"] += 1

    if IsOverlapped(): 
        obj_pos["y"] -= 1
        Grids["Player1"] = CombineMatrices()
        SpawnPart()

def rotation_right(grid):
    a=[1,1,1,1]
    b=[1,1,1,1]
    c=[1,1,1,1]
    d=[1,1,1,1]

    new_list=[]
    shape=[]
    oszlop=[]
    sor=[]


    for i in range(4):
        for j in range(4):
            if grid[i][j]>1:
                value=grid[i][j]
                shape+=[i,j]


    for i in range(1,8,2):
        j=shape[i]
        oszlop+=[j]
    
    for i in range(0,7,2):
        j=shape[i]
        sor+=[j]

    if sor[0]==sor[3] and sor[2]==sor[1] and sor[2]==sor[3]:
        a[2]=[value]
        b[2]=[value]
        c[2]=[value]
        d[2]=[value]
    
        new_list=[a,b,c,d]

    elif oszlop[0]==oszlop[3] and oszlop[2]==oszlop[1] and oszlop[2]==oszlop[3]:
        c=[value,value,value,value]
    
        new_list=[a,b,c,d]

    elif shape[0]==shape[2] and shape[1]==shape[5]:
        new_list=grid
    
    elif (max(sor)-1)==min(sor):
        new_list=[a,b,c,d]
        sormarker=False
        oszlopmarker=False

        if sor[0]==3 or sor[1]==3 or sor[2]==3 or sor[3]==3:
            for i in range(4):
                sor[i]-=1
            sormarker=True

        if oszlop[0]==3 or oszlop[1]==3 or oszlop[2]==3 or oszlop[3]==3:
            for i in range(4):
                oszlop[i]-=1
            oszlopmarker=True
        
        rotation_list=[[1,1,1],[1,1,1],[1,1,1]]
        for i in range(4):
            jel=sor[i]
            jel2=oszlop[i]
            rotation_list[jel][jel2]=value

        rot_list1=rotation_list[0]
        rot_list2=rotation_list[1]
        rot_list3=rotation_list[2]

        new_rot_list1=[rot_list3[0],rot_list2[0],rot_list1[0]]
        new_rot_list2=[rot_list3[1],rot_list2[1],rot_list1[1]]
        new_rot_list3=[rot_list3[2],rot_list2[2],rot_list1[2]]

        new_rotation_list=[new_rot_list1,new_rot_list2,new_rot_list3]

        for i in range(3):
            for j in range(3):
                if sormarker and oszlopmarker:
                    new_list[i+1][j+1]=new_rotation_list[i][j]
                elif sormarker:
                    new_list[i+1][j]=new_rotation_list[i][j]
                elif oszlopmarker:
                    new_list[i][j+1]=new_rotation_list[i][j]
                else:
                    new_list[i][j]=new_rotation_list[i][j]

    else:
        new_list=[a,b,c,d]
        sormarker=False
        oszlopmarker=False

        if sor[0]==3 or sor[1]==3 or sor[2]==3 or sor[3]==3:
            for i in range(4):
                sor[i]-=1
            sormarker=True

        if oszlop[0]==3 or oszlop[1]==3 or oszlop[2]==3 or oszlop[3]==3:
            for i in range(4):
                oszlop[i]-=1
            oszlopmarker=True
        
        rotation_list=[[1,1,1],[1,1,1],[1,1,1]]
        for i in range(4):
            jel=sor[i]
            jel2=oszlop[i]
            rotation_list[jel][jel2]=value

        rot_list1=rotation_list[0]
        rot_list2=rotation_list[1]
        rot_list3=rotation_list[2]
        
        #print(rot_list1,rot_list2,rot_list3)

        new_rot_list1=[rot_list3[0],rot_list2[0],rot_list1[0]]
        new_rot_list2=[rot_list3[1],rot_list2[1],rot_list1[1]]
        new_rot_list3=[rot_list3[2],rot_list2[2],rot_list1[2]]

        #print(new_rot_list1,new_rot_list2,new_rot_list3)

        new_rotation_list=[new_rot_list1,new_rot_list2,new_rot_list3]

        for i in range(3):
            for j in range(3):
                if sormarker and oszlopmarker:
                    new_list[i+1][j+1]=new_rotation_list[i][j]
                elif sormarker:
                    new_list[i+1][j]=new_rotation_list[i][j]
                elif oszlopmarker:
                    new_list[i][j+1]=new_rotation_list[i][j]
                else:
                    new_list[i][j]=new_rotation_list[i][j]


    #print(shape)
    #print(sor)
    #print(oszlop)
    #print(grid)
    #print(new_list)
    return new_list


def rotation_left(grid):
    a=[1,1,1,1]
    b=[1,1,1,1]
    c=[1,1,1,1]
    d=[1,1,1,1]

    new_list=[]
    shape=[]
    oszlop=[]
    sor=[]


    for i in range(4):
        for j in range(4):
            if grid[i][j]>1:
                value=grid[i][j]
                shape+=[i,j]


    for i in range(1,8,2):
        j=shape[i]
        oszlop+=[j]
    
    for i in range(0,7,2):
        j=shape[i]
        sor+=[j]

    if sor[0]==sor[3] and sor[2]==sor[1] and sor[2]==sor[3]:
        a[2]=[value]
        b[2]=[value]
        c[2]=[value]
        d[2]=[value]
    
        new_list=[a,b,c,d]

    elif oszlop[0]==oszlop[3] and oszlop[2]==oszlop[1] and oszlop[2]==oszlop[3]:
        c=[value,value,value,value]
    
        new_list=[a,b,c,d]

    elif shape[0]==shape[2] and shape[1]==shape[5]:
        new_list=grid
    
    elif (max(sor)-1)==min(sor):
        new_list=[a,b,c,d]
        sormarker=False
        oszlopmarker=False

        if sor[0]==3 or sor[1]==3 or sor[2]==3 or sor[3]==3:
            for i in range(4):
                sor[i]-=1
            sormarker=True

        if oszlop[0]==3 or oszlop[1]==3 or oszlop[2]==3 or oszlop[3]==3:
            for i in range(4):
                oszlop[i]-=1
            oszlopmarker=True
        
        rotation_list=[[1,1,1],[1,1,1],[1,1,1]]
        for i in range(4):
            jel=sor[i]
            jel2=oszlop[i]
            rotation_list[jel][jel2]=value

        rot_list1=rotation_list[0]
        rot_list2=rotation_list[1]
        rot_list3=rotation_list[2]

        new_rot_list1=[rot_list1[2],rot_list2[2],rot_list3[2]]
        new_rot_list2=[rot_list1[1],rot_list2[1],rot_list3[1]]
        new_rot_list3=[rot_list1[0],rot_list2[0],rot_list3[0]]

        new_rotation_list=[new_rot_list1,new_rot_list2,new_rot_list3]

        for i in range(3):
            for j in range(3):
                if sormarker and oszlopmarker:
                    new_list[i+1][j+1]=new_rotation_list[i][j]
                elif sormarker:
                    new_list[i+1][j]=new_rotation_list[i][j]
                elif oszlopmarker:
                    new_list[i][j+1]=new_rotation_list[i][j]
                else:
                    new_list[i][j]=new_rotation_list[i][j]

    else:
        new_list=[a,b,c,d]
        sormarker=False
        oszlopmarker=False

        if sor[0]==3 or sor[1]==3 or sor[2]==3 or sor[3]==3:
            for i in range(4):
                sor[i]-=1
            sormarker=True

        if oszlop[0]==3 or oszlop[1]==3 or oszlop[2]==3 or oszlop[3]==3:
            for i in range(4):
                oszlop[i]-=1
            oszlopmarker=True
        
        rotation_list=[[1,1,1],[1,1,1],[1,1,1]]
        for i in range(4):
            jel=sor[i]
            jel2=oszlop[i]
            rotation_list[jel][jel2]=value

        rot_list1=rotation_list[0]
        rot_list2=rotation_list[1]
        rot_list3=rotation_list[2]
        
        #print(rot_list1,rot_list2,rot_list3)

        new_rot_list1=[rot_list1[2],rot_list2[2],rot_list3[2]]
        new_rot_list2=[rot_list1[1],rot_list2[1],rot_list3[1]]
        new_rot_list3=[rot_list1[0],rot_list2[0],rot_list3[0]]

        #print(new_rot_list1,new_rot_list2,new_rot_list3)

        new_rotation_list=[new_rot_list1,new_rot_list2,new_rot_list3]

        for i in range(3):
            for j in range(3):
                if sormarker and oszlopmarker:
                    new_list[i+1][j+1]=new_rotation_list[i][j]
                elif sormarker:
                    new_list[i+1][j]=new_rotation_list[i][j]
                elif oszlopmarker:
                    new_list[i][j+1]=new_rotation_list[i][j]
                else:
                    new_list[i][j]=new_rotation_list[i][j]
    return new_list

def Rotate(clockwise):
    global Obj_Grid
    Prev_Obj_Grid = Obj_Grid
    if clockwise: 
        Obj_Grid = rotation_right(Obj_Grid)
    else: 
        Obj_Grid = rotation_left(Obj_Grid)
    
    if IsOverlapped(): 
        Obj_Grid = Prev_Obj_Grid


skip_input = True
def main(window):

    global skip_input, menu_stage, run_context, opponent_ip

    #Configure curses
    curses.halfdelay(1)

    # Adjust default color values
    def RGBToCurse(num): return round(num * 3.921)
    curses.init_color(curses.COLOR_WHITE, RGBToCurse(252), RGBToCurse(255), RGBToCurse(254))    # WHITE
    curses.init_color(curses.COLOR_BLACK, RGBToCurse(20), RGBToCurse(20), RGBToCurse(20))       # BLACK
    curses.init_color(curses.COLOR_GREEN, RGBToCurse(71), RGBToCurse(255), RGBToCurse(102))     # GREEN
    curses.init_color(curses.COLOR_RED, RGBToCurse(255), RGBToCurse(71), RGBToCurse(90))        # RED
    curses.init_color(curses.COLOR_CYAN, RGBToCurse(71), RGBToCurse(255), RGBToCurse(234))      # CYAN
    curses.init_color(curses.COLOR_YELLOW, RGBToCurse(255), RGBToCurse(249), RGBToCurse(71))    # YELLOW
    curses.init_color(curses.COLOR_BLUE, RGBToCurse(71), RGBToCurse(132), RGBToCurse(255))      # BLUE
    curses.init_color(curses.COLOR_MAGENTA, RGBToCurse(255), RGBToCurse(71), RGBToCurse(246))   # MAGENTA

    # Define stylingz
    curses.init_pair(1, curses.COLOR_BLACK, curses.COLOR_BLACK)     # BLACK  on BLACK
    curses.init_pair(2, curses.COLOR_WHITE, curses.COLOR_BLACK)     # WHITE  on BLACK
    curses.init_pair(3, curses.COLOR_GREEN, curses.COLOR_BLACK)     # GREEN  on BLACK
    curses.init_pair(4, curses.COLOR_RED, curses.COLOR_BLACK)       # RED    on BLACK
    curses.init_pair(5, curses.COLOR_YELLOW, curses.COLOR_BLACK)    # YELLOW on BLACK
    curses.init_pair(6, curses.COLOR_BLUE, curses.COLOR_BLACK)      # BLUE   on BLACK
    curses.init_pair(7, curses.COLOR_MAGENTA, curses.COLOR_BLACK)   # MAGENT on BLACK
    curses.init_pair(8, curses.COLOR_CYAN, curses.COLOR_BLACK)      # CYAN   on BLACK
    curses.init_pair(9, curses.COLOR_BLACK, curses.COLOR_CYAN)      # BLACK  on CYAN [FOR SELECT]
    curses.init_pair(10, curses.COLOR_BLACK, curses.COLOR_WHITE)    # BLACK  on WHITE

    # Function to safely draw curses elements
    def AddStr(y, x, text, col=2):  
        try:
            window.addstr(y, x, text, curses.color_pair(col))
        except: pass;
    
    def FillGrid(gridname):
        Grids[gridname] = []
        for y in range(0, CFG["grid_y"]):
            Grids[gridname].append([])
            for x in range(0, CFG["grid_x"]):
                Grids[gridname][y].append(1)

    FillGrid("Player1")
    FillGrid("Player2")   

    # Task schedular >:3
    while True:
        keycode = 0
        if (not skip_input):
            new_keycode = window.getch()
            keycode = new_keycode != -1 and new_keycode or keycode
            if keycode == curses.KEY_RESIZE:
                keycode = -1
                continue
        else: skip_input = False
        
        # Clear last window
        # Do this before drawing
        window.erase()

        if menu_stage == 0: # Main menu AIZE
            AddStr(2, 1,  "  ─█▀▀█ ▀█▀ ░█▀▀▀█ ░█▀▀▀ ░░░░░░░░░░░", 8)
            AddStr(3, 1,  "  ░█▄▄█ ░█─ ─▄▄▄▀▀ ░█▀▀ ░░░░░░░░░", 8)
            AddStr(4, 1,  "  ░█─░█ ▄█▄ ░█▄▄▄█ ░█▄▄▄ ░░░░░░░░░░░░░░", 8)

            AddStr(6, 15,    "████████╗███████╗███████╗██████╗ ██╗███████╗ ░░░░░░░░░░░", 5)
            AddStr(7, 15,    "╚══██╔══╝██╔════╝╚════██║██╔══██╗██║██╔════╝ ░░░░░░░", 5)
            AddStr(8, 14,   "    ██║   █████╗      ██╔╝██████╔╝██║███████╗   ░░░░░░░░░░", 5)
            AddStr(9, 13,  "     ██║   ██╔══╝     ██╔╝ ██╔══██╗██║╚════██║ ░░░░░░░░", 5)
            AddStr(10, 13, "     ██║   ███████╗   ██║  ██║  ██║██║███████║ ░░░", 5)
            AddStr(11,13,  "     ╚═╝   ╚══════╝   ╚═╝  ╚═╝  ╚═╝╚═╝╚══════╝   ░", 5)

            AddStr(13, 1, "==============", 7)
            AddStr(15, 1, "HOST / JOIN", 2)
            AddStr(17, 1, "==============", 7)

            #
            AddStr(7, 1, "Keycode: " + str(keycode), 1)

            if keycode == 97:
                Menu_Vars[0]["select"] = max(Menu_Vars[0]["select"] - 1, 0)
            elif keycode == 100:
                Menu_Vars[0]["select"] = min(Menu_Vars[0]["select"] + 1, 1)

            if Menu_Vars[0]["select"] == 0:
                AddStr(15, 1,  "HOST", 9)
            else:
                AddStr(15, 8,  "JOIN", 9)
            
            if keycode == 10:
                menu_stage = 1
                run_context = Menu_Vars[0]["select"]

        elif menu_stage == 1: # Host menu
            if run_context == 0:
                # Selected server, wait for connection
                AddStr(1, 1,  "::HOST::", 10)
            else: 
                AddStr(1, 1,  "::CLIENT::", 10)


            # Prompt for IP
            if keycode - 48 in range(0, 10):
                opponent_ip += str(keycode - 48)
            elif keycode == 46: # Dot
                opponent_ip += "."
            elif keycode == 263: # Backspace
                opponent_ip = opponent_ip[0:-1]
            elif keycode == 10: # Enter
                menu_stage = 2
                continue
            elif keycode == 27: # Escape
                menu_stage = 0 
                continue
                
            AddStr(3, 1, "IP: " + opponent_ip, 2)

                
        elif menu_stage == 2:
            # Show connecting signal
            #Menu_Vars[2]["conn_bar"] = Menu_Vars[2]["conn_bar"][9] + Menu_Vars[2]["conn_bar"][0:-1]
            #AddStr(3, 1,  "Establishing Connection [" + Menu_Vars[2]["conn_bar"] + "]", 2)

            if run_context == 0: 
                
                # Server replication
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.bind((opponent_ip, CFG["tcp_port"]))
                    s.listen()
                    conn, addr = s.accept()
                    with conn:
                        while True:

                            data = conn.recv(1024)
                            if data:
                                Grids["Player2"] = json.loads(data)

                            conn.sendall(json.dumps(CombineMatrices()).encode())
                            
                            
                            window.nodelay(1)
                            keycode = 0
                            try: 
                                keycode = window.getch()
                            except: pass;
                            
                            Grids["Player1"] = LineClear.line_clear(Grids["Player1"])

                            window.erase()

                            if keycode == 115:   # Down
                                PushDown()
                            elif keycode == 97: # Left 
                                Strafe(-1) 
                            elif keycode == 100: # Right
                                Strafe(1)
                            elif keycode == 113:
                                Rotate(False)
                            elif keycode == 101:
                                Rotate(True)

                            # Render grid 1 container
                            grid_1_offset = {"x": 10, "y": 2}
                            for y_coord in range(0, CFG["grid_y"] - 4):
                                for x_coord in range(0, CFG["grid_x"] + 2):
                                    AddStr(y_coord + grid_1_offset["y"] + 1, x_coord * 2 + grid_1_offset["x"] - 2, "██", 2)

                            # Render grid 1
                            for y_coord, Y_Row in enumerate(Grids["Player1"]):
                                if y_coord == CFG["grid_y"] - 4: break;
                                for x_coord, color in enumerate(Y_Row):
                                    AddStr(y_coord + grid_1_offset["y"], x_coord * 2 + grid_1_offset["x"], "██", color)
                            
                            if CFG["debug_show_matrix"]:
                                for y_coord, Y_Row in enumerate(Grids["Player1"]):
                                    for x_coord, color in enumerate(Y_Row):
                                        AddStr(y_coord + grid_1_offset["y"], x_coord * 2 + grid_1_offset["x"], f".{color}", color)

                            # Render Obj grid
                            for y_coord, Y_Row in enumerate(Obj_Grid):
                                for x_coord, color in enumerate(Y_Row):
                                    if color == 1: continue;
                                    AddStr(y_coord + obj_pos["y"] + grid_1_offset["y"], (x_coord + obj_pos["x"]) * 2 + grid_1_offset["x"], "██", color)
                                    
                            # Render grid 2 container
                            grid_2_offset = {"x": 40, "y": 2}
                            for y_coord in range(0, CFG["grid_y"] - 4):
                                for x_coord in range(0, CFG["grid_x"] + 2):
                                    AddStr(y_coord + grid_2_offset["y"] + 1, x_coord * 2 + grid_2_offset["x"] - 2, "██", 2)

                            # Render grid 2
                            for y_coord, Y_Row in enumerate(Grids["Player2"]):
                                if y_coord == CFG["grid_y"] - 4: break;
                                for x_coord, color in enumerate(Y_Row):
                                    AddStr(y_coord + grid_2_offset["y"], x_coord * 2 + grid_2_offset["x"], "██", color)
                                    
                            if CFG["debug_show_matrix"]:
                                for y_coord, Y_Row in enumerate(Grids["Player2"]):
                                    for x_coord, color in enumerate(Y_Row):
                                        AddStr(y_coord + grid_2_offset["y"], x_coord * 2 + grid_2_offset["x"], f".{color}", 2)

                            AutoDrop()

                            window.refresh()
            else: 
                
                # Client replication
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.connect((opponent_ip, CFG["tcp_port"]))
                    while True: 
                        s.sendall(json.dumps(CombineMatrices()).encode())
                        data = s.recv(1024)
                        if data: 
                            Grids["Player2"] = json.loads(data)

                        
                        window.nodelay(1)
                        keycode = 0
                        try: 
                            keycode = window.getch()
                        except: pass;
                        
                        Grids["Player1"] = LineClear.line_clear(Grids["Player1"])

                        window.erase()

                        if keycode == 258:   # Down
                                PushDown()
                        elif keycode == 260: # Left 
                            Strafe(-1) 
                        elif keycode == 261: # Right
                            Strafe(1)

                        # Render grid 1 container
                        grid_1_offset = {"x": 10, "y": 2}
                        for y_coord in range(0, CFG["grid_y"] - 4):
                            for x_coord in range(0, CFG["grid_x"] + 2):
                                AddStr(y_coord + grid_1_offset["y"] + 1, x_coord * 2 + grid_1_offset["x"] - 2, "██", 2)

                        # Render grid 1
                        for y_coord, Y_Row in enumerate(Grids["Player1"]):
                            if y_coord == CFG["grid_y"] - 4: break;
                            for x_coord, color in enumerate(Y_Row):
                                AddStr(y_coord + grid_1_offset["y"], x_coord * 2 + grid_1_offset["x"], "██", color)
                        
                        if CFG["debug_show_matrix"]:
                            for y_coord, Y_Row in enumerate(Grids["Player1"]):
                                for x_coord, color in enumerate(Y_Row):
                                    AddStr(y_coord + grid_1_offset["y"], x_coord * 2 + grid_1_offset["x"], f".{color}", color)

                        # Render Obj grid
                        for y_coord, Y_Row in enumerate(Obj_Grid):
                            for x_coord, color in enumerate(Y_Row):
                                if color == 1: continue;
                                AddStr(y_coord + obj_pos["y"] + grid_1_offset["y"], (x_coord + obj_pos["x"]) * 2 + grid_1_offset["x"], "██", color)
                        
                        # Render grid 2 container
                        grid_2_offset = {"x": 40, "y": 2}
                        for y_coord in range(0, CFG["grid_y"] - 4):
                            for x_coord in range(0, CFG["grid_x"] + 2):
                                AddStr(y_coord + grid_2_offset["y"] + 1, x_coord * 2 + grid_2_offset["x"] - 2, "██", 2)

                        # Render grid 2
                        for y_coord, Y_Row in enumerate(Grids["Player2"]):
                            if y_coord == CFG["grid_y"] - 4: break;
                            for x_coord, color in enumerate(Y_Row):
                                AddStr(y_coord + grid_2_offset["y"], x_coord * 2 + grid_2_offset["x"], "██", color)
                                
                        if CFG["debug_show_matrix"]:
                            for y_coord, Y_Row in enumerate(Grids["Player2"]):
                                for x_coord, color in enumerate(Y_Row):
                                    AddStr(y_coord + grid_2_offset["y"], x_coord * 2 + grid_2_offset["x"], f".{color}", 2)

                        AutoDrop()
                        window.refresh()

                        


        # Show new screen
        # Do this after drawing
        window.refresh()

curses.wrapper(main)