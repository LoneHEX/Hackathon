#Line clear
#Martin Meszaros
#Hackathon 2023
#clears a full line
#26/02/2023

def do_line_clear(matrix_in,a):
    matrix_out=[]

    for i in range(0,19,-1):
        if i<=a:
            j=i-1
            if j<0:
                j=0
        else:
            j=i

        matrix_out[i]=matrix_in[j]

    return matrix_out

            


def line_clear(matrix_in):
    for i in range(0,19,-1):
        tester=0
        for j in range(10):
            if matrix_in[i][j]<1:
                tester+=1
                if tester>=9:
                    matrix_in=do_line_clear(matrix_in,i)
    return matrix_in


